// question 1
var firstVar = "";
let firstLet = "";
const firstConst = "";

// question 2
var name = "Jonmar";
console.log(name);

// question 3
var age = 23;
console.log(age);

var height = 170 + "cm";
console.log(height);

// Show off...
const person = {
  firstName: "Jonmar",
  lastName: "Tamon",
  age: 23,
  nationality: "Filipino"
};

// question 4
var division = 20 / 5;
console.log(division);

// question 5
var checkValue = typeof "frog";
console.log(checkValue);

// question 6
var orderHasShipped = false;

console.log(
  'The variable "orderHasShipped" is a ' +
    typeof orderHasShipped +
    ", that has a value of " +
    orderHasShipped
);

// question 7

if (orderHasShipped) {
  console.log("true");
} else {
  console.log("false");
}

// question 8

for (let i = 0; i <= 9; i++) {
  const count = i;

  console.log(count);
}
